var typed =  new typed(".typing",{
    strings:["student","web developer","web designer"],
    typeSpeed:100,
    BackSpeed:60,
    loop:true
}

const nav = document.querySelector(".nav"),

    